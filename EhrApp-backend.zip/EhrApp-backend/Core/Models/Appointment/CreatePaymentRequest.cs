﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Models.Appointment
{
    public class CreatePaymentRequest
    {
        public decimal Amount { get; set; }
    }
}
