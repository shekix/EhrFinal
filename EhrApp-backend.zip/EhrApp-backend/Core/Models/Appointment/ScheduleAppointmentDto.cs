﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Models.Appointment
{
    public class ScheduleAppointmentDto
    {
        public int PatientId { get; set; }
        public int ProviderId { get; set; }
        public DateOnly AppointmentDate { get; set; }
        public TimeOnly AppointmentTime { get; set; }
        public required string CheifComplaint { get; set; }
        public required string Status { get; set; }
        public float? Fee { get; set; }
    }
}
