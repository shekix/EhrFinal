﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Models.Appointment
{
    public class providerAppointmentDetails
    {
        public int Id { get; set; }
        public int PatientId { get; set; }
        public string PatientName { get; set; }
        public DateOnly AppointmentDate { get; set; }
        public TimeOnly AppointmentTime { get; set; }
        public required string CheifComplaint { get; set; }
        public required string Status { get; set; }
        public required float Fee { get; set; }
    }
}
