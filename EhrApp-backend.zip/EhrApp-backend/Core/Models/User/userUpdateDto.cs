﻿using Domain.Provider;
using Domain.StateCity;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.User
{
    public class userUpdateDto
    {
        public int Id { get; set; }
        public required string FirstName { get; set; }
        public required string LastName { get; set; }
        public required string Email { get; set; }
        public DateTime Dob { get; set; }
        public int GenderId { get; set; }
        public int BloodGroupId { get; set; }
        public required string Mobile { get; set; }
        public int Country { get; set; }
        public int StateId { get; set; }
        public required string City { get; set; }
        public required string Address { get; set; }
        public required string Pincode { get; set; }
        public IFormFile? ProfileImage { get; set; }
        public int? QualificationId { get; set; }
        public int? SpecializationId { get; set; }
        public string? RegistrationNumber { get; set; }
        public float? VisitingCharge { get; set; }
    }
}
