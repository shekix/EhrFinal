﻿using Core.Models.Appointment;
using Infrastructure.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace EhrApp_backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AppointmentController : ControllerBase
    {
        private readonly AppointmentService _appointmentService;
        private readonly StripeService _stripeService;

        public AppointmentController(AppointmentService appointmentService, StripeService stripeService)
        {
            _appointmentService = appointmentService;
            _stripeService = stripeService;
        }

        [HttpPost("addAppointment")]
        public async Task<IActionResult> addAppointment(ScheduleAppointmentDto dto)
        {
            var result = await _appointmentService.scheduleAppointment(dto);
            if (result != null)
            {
                return Ok(result);
            }
            return BadRequest();
        }

        [HttpGet("Specializations")]
        public async Task<IActionResult> specializations()
        {
            var result = await _appointmentService.GetSpecializations();
            if (result != null)
            {
                return Ok(result);
            }
            return BadRequest();
        }

        [HttpGet("Providers")]
        public async Task<IActionResult> providers()
        {
            var result = await _appointmentService.GetProviders();
            if (result != null)
            {
                return Ok(result);
            }
            return BadRequest();
        }

        [HttpGet("Patients")]
        public async Task<IActionResult> patients()
        {
            var result = await _appointmentService.GetPatients();
            if (result != null)
            {
                return Ok(result);
            }
            return BadRequest();
        }

        [HttpGet("ProvidersById")]
        public async Task<IActionResult> providersById(int Id)
        {
            var result = await _appointmentService.GetProvidersbySpeicalization(Id);
            if (result != null)
            {
                return Ok(result);
            }
            return BadRequest();
        }

        [HttpPost("create-payment-intent")]
        public async Task<IActionResult> CreatePaymentIntent([FromBody] CreatePaymentRequest request)
        {
            var paymentIntentClientSecret = await _stripeService.CreatePaymentIntent(request.Amount);
            return Ok(new { clientSecret = paymentIntentClientSecret });
        }

        [HttpGet("patientAppointmentDetails")]
        public async Task<IActionResult> getPatientDetails(int PatientId)
        {
            var result = await _appointmentService.getPatientAppointmentDetails(PatientId);
            if(result != null)
            {
                return Ok(result);
            }
            return BadRequest();
        }


        [HttpGet("providerAppointmentDetails")]
        public async Task<IActionResult> getProviderDetails(int ProviderId)
        {
            var result = await _appointmentService.getProviderAppointmentDetails(ProviderId);
            if (result != null)
            {
                return Ok(result);
            }
            return BadRequest();
        }

        [HttpGet("byId")]
        public async Task<IActionResult> getAppointmentDetails(int Id)
        {
            var result = await _appointmentService.AppointmentDetails(Id);
            if (result != null)
            {
                return Ok(result);
            }
            return BadRequest();
        }

        [HttpDelete("cancel")]
        public async Task<IActionResult> cancelAppointment(int appointmentId)
        {
            var result = await _appointmentService.CancelAppointment(appointmentId);
            if(result == true)
            {
                return Ok(result);
            }
            return BadRequest(result);
        }

        [HttpPut("updateAppointment")]
        public async Task <IActionResult> updateAppointment(updateAppointment dto)
        {
            var result = await _appointmentService.updateAppointment(dto);
            if(result == true)
            {
                return Ok(result);
            }
            return BadRequest(result);
        }

        [HttpPost("addSoap")]
        public async Task<IActionResult> addSoap(soapDto dto)
        {
            var result = await _appointmentService.addSoap(dto);
            if (result == true)
            {
                return Ok(result);
            }
            return BadRequest(result);
        }

        [HttpPut("updateStatus")]
        public async Task<IActionResult> updateStatus(int id)
        {
            var result = await _appointmentService.updateStatus(id);
            if (result == true)
            {
                return Ok(result);
            }
            return BadRequest(result);
        }

        [HttpGet("previousAppointments")]
        public async Task<IActionResult> previousAppointments(int id)
        {
            var result = await _appointmentService.previousAppointment(id);
            if(result != null)
            {
                return Ok(result);
            }
            return BadRequest(result);
        }

        [HttpGet("viewAppointment")]
        public async Task<IActionResult> viewAppointment(int id)
        { 
            var result = await _appointmentService.viewAppointment(id);
            if(result == null)
            {
                return BadRequest();
            }
            return Ok(result);
        }
    }
}
