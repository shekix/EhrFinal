﻿using Core.Models.User;
using Domain.User;
using Infrastructure.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace EhrApp_backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly RegistrationLoginService _registrationService;
        private readonly UserService _userService;
        public UserController(RegistrationLoginService registrationService,UserService userService)
        {
            _registrationService = registrationService;
            _userService = userService;

        }

        [HttpPost("Register")]
        public async Task<IActionResult> userRegistration([FromForm] userRegistrationDto dto)
        {
            var result = await _registrationService.userRegistration(dto);
            if (result != null)
            {
                return Ok(result);
            }
            return Conflict("user with this email already exists");
        }


        [HttpPost("Login")]
        public async Task<IActionResult> userLogin(userLoginDto dto)
        {
            var result = await _registrationService.userLogin(dto);
            if (result)
            {
                return Ok("Successful");
            }
            return Unauthorized("unsuccessfulLogin");
        }

        [HttpPost("2FA")]
        public async Task<IActionResult> userVerification(OtpVerficationDto dto)
        {
            var result = await _registrationService.userVerification(dto);
            if (result == "unsuccessful")
            {
                return BadRequest("unsuccessful");
            }
            return Ok(result);
        }

        [HttpPost("ForgotPass")]
        public async Task<IActionResult> forgotPass(string email)
        {
            var result = await _registrationService.forgotPassword(email);
            if (result == "unsuccessful")
            {
                return NotFound(email);
            }
            return Ok(result);
        }

        [HttpPut("ChangePass")]
        public async Task<IActionResult> changePass(chanegPassDta dto)
        {
            var result = await _registrationService.changePassword(dto);
            if (result == "unsuccessful")
            {
                return BadRequest(result);
            }
            return Ok(result);
        }


        [HttpGet("userById")]
        public async Task<IActionResult> userById(int id)
        {
            var result = await _userService.getUserInfo(id);
            return Ok(result);
        }

        [HttpPut("update")]
        public async Task<IActionResult> updateUser([FromForm] userUpdateDto dto)
        {
            var result = await _userService.updateUserInfo(dto);
            if (result == "success")
            {
                return Ok(result);
            }
            return BadRequest(result);
        }
    }
}
