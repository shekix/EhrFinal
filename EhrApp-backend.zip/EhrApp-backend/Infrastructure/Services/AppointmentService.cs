﻿using Core.Interfaces;
using Core.Models.Appointment;
using Core.Models.User;
using Dapper;
using Domain.Appointment;
using Domain.Provider;
using Domain.User;
using Infrastructure.Database;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Identity.Client;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace Infrastructure.Services
{
    public class AppointmentService
    {
        private readonly AppDbContext _context;
        private readonly IConfiguration _configuration;
        private readonly IEmailService _emailService;
        private readonly SqlConnection connection;

        public AppointmentService(AppDbContext context, IEmailService emailService, IConfiguration configuration)
        {
            _context = context;
            _emailService = emailService;
            _configuration = configuration;
            connection = new SqlConnection(configuration.GetConnectionString("DefaultConnection"));
           
        }

        public async Task<ScheduleAppointmentDto> scheduleAppointment(ScheduleAppointmentDto dto)
        {
            DateTime now = DateTime.Now.AddMinutes(60);
            var time = TimeOnly.FromDateTime(now);
            if(dto.AppointmentTime < time)
            {
                return null;
            }
            
            var provider = _context.Users.Where(p=>p.Id == dto.ProviderId).FirstOrDefault();
            var patient = _context.Users.Where(p=>p.Id == dto.PatientId).FirstOrDefault();
            if(dto.Fee == 0)
            {
                dto.Fee = provider.VisitingCharge;
            }
            var appointment = new Appointment
            {
                PatientId = dto.PatientId,
                ProviderId = dto.ProviderId,
                AppointmentDate = dto.AppointmentDate,
                AppointmentTime = dto.AppointmentTime,
                CheifComplaint = dto.CheifComplaint,
                Status = dto.Status,
                Fee = (float)dto.Fee,
            };

            await _context.Appointments.AddAsync(appointment);
            await _context.SaveChangesAsync();
            await _emailService.SendEmailAsync(
                patient.Email,
                "Appointment scheduled",
                "your appointment has been scheduled with Dr."+provider.FirstName + " " + provider.LastName +
                "<br> DATE: " + dto.AppointmentDate +
                "<br> TIME: " + dto.AppointmentTime
            );
            await _emailService.SendEmailAsync(
                provider.Email,
                "Appointment scheduled",
                "Your appointment has been scheduled with " + patient.FirstName + " " + patient.LastName +
                "<br> DATE: " + dto.AppointmentDate +
                "<br> TIME: " + dto.AppointmentTime
            );
            return dto;
        }

        public async Task<IEnumerable<Specialization>> GetSpecializations()
        {
            var result = await _context.Specializations.ToListAsync();
            return result;
        }

        public async Task<IEnumerable<User>> GetProviders()
        {
            var result = await _context.Users.Where(u=>u.UserType == 1).ToListAsync();
            return result;
        }

        public async Task<IEnumerable<User>> GetProvidersbySpeicalization(int id)
        {
            var result = await _context.Users.Where(u=>u.SpecializationId == id).ToListAsync();
            return result;
        }

        public async Task<IEnumerable<User>> GetPatients()
        {
            var result = await _context.Users.Where(u => u.UserType == 2).ToListAsync();
            return result;
        }


        public async Task<IEnumerable<patientAppointmentDetails>> getPatientAppointmentDetails(int patientId)
        {
            var appointments = new List<patientAppointmentDetails>();
            var scheduledAppointments = await _context.Appointments.Where(p=>p.PatientId == patientId && p.Status== "Scheduled").OrderBy(a => a.AppointmentDate).ThenBy(a => a.AppointmentTime).ToListAsync();
            foreach(var appointment in scheduledAppointments)
            {
                var userData = await _context.Users.Where(u => u.Id == appointment.ProviderId).FirstOrDefaultAsync();
                var ProviderName = userData.FirstName +" "+userData.LastName;
                appointments.Add(new patientAppointmentDetails
                {
                    Id = appointment.Id,
                    ProviderId = appointment.ProviderId,
                    ProviderName = ProviderName,
                    AppointmentDate = appointment.AppointmentDate,
                    AppointmentTime = appointment.AppointmentTime,
                    Status = appointment.Status,
                    CheifComplaint = appointment.CheifComplaint,
                    Fee = appointment.Fee,
                });
            }

            return appointments;
        }


        public async Task<IEnumerable<providerAppointmentDetails>> getProviderAppointmentDetails(int providerId)
        {
            var appointments = new List<providerAppointmentDetails>();
            var scheduledAppointments =  await _context.Appointments.Where(p => p.ProviderId == providerId && p.Status == "Scheduled").OrderBy(a => a.AppointmentDate).ThenBy(a => a.AppointmentTime).ToListAsync();
            foreach (var appointment in scheduledAppointments)
            {
                var userData = await _context.Users.Where(u => u.Id == appointment.PatientId).FirstOrDefaultAsync();
                var PatientName = userData.FirstName + " " + userData.LastName;
                appointments.Add(new providerAppointmentDetails
                {
                    Id= appointment.Id,
                    PatientId = appointment.PatientId,
                    PatientName = PatientName,
                    AppointmentDate = appointment.AppointmentDate,
                    AppointmentTime = appointment.AppointmentTime,
                    Status = appointment.Status,
                    CheifComplaint = appointment.CheifComplaint,
                    Fee = appointment.Fee,
                });
            }

            return appointments;
        }

        public async Task<IEnumerable<dynamic>> AppointmentDetails(int Id)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@Id", Id);

            var result = await connection.QueryAsync<dynamic>("appointmentdetails", parameters, commandType: CommandType.StoredProcedure);
            return result;

        }

        public async Task<bool> updateAppointment(updateAppointment dto)
        {
            var appointment = await _context.Appointments.Where(a=>a.Id == dto.AppointmentId).FirstOrDefaultAsync();
            
            if (appointment == null)
            {
                return false;
            }
            var provider = await _context.Users.Where(u => u.Id == appointment.ProviderId).FirstOrDefaultAsync();
            var patient = await _context.Users.Where(u => u.Id == appointment.PatientId).FirstOrDefaultAsync();
            appointment.AppointmentDate = dto.AppointmentDate;
            appointment.AppointmentTime = dto.AppointmentTime;
            appointment.CheifComplaint  = dto.CheifComplaint;

            await _context.SaveChangesAsync();
            await _emailService.SendEmailAsync(
                patient.Email,
                "Appointment rescheduled",
                "Your appointment has been rescheduled with Dr." + provider.FirstName + " " + provider.LastName +
                "<br> DATE: " + dto.AppointmentDate +
                "<br>TIME: " + dto.AppointmentTime +
                "<br> COMPLAIN: " +dto.CheifComplaint
            );
            await _emailService.SendEmailAsync(
              provider.Email,
              "Appointment rescheduled",
              "Your appointment has been rescheduled with " + patient.FirstName + " " + patient.LastName +
              "<br> DATE: " + dto.AppointmentDate +
              "<br> TIME: " + dto.AppointmentTime +
              "<br> COMPLAIN: " + dto.CheifComplaint
          );
            return true;
        }

        public async Task<bool> CancelAppointment(int id)
        {
            var appointment = await _context.Appointments.FirstOrDefaultAsync(a => a.Id == id);
            if (appointment == null)
            {
                return false;
            }
            var provider = await _context.Users.Where(u => u.Id == appointment.ProviderId).FirstOrDefaultAsync();
            var patient = await _context.Users.Where(u => u.Id == appointment.PatientId).FirstOrDefaultAsync();
            appointment.Status = "Cancelled";
            await _context.SaveChangesAsync();
            await _emailService.SendEmailAsync(
              patient.Email,
              "Appointment cancelled",
              "Your appointment with Dr." + provider.FirstName + " " + provider.LastName + " has been cancelled"
             );
            await _emailService.SendEmailAsync(
              provider.Email,
              "Appointment cancelled",
              "Your appointment with " + patient.FirstName + " " + patient.LastName + " has been cancelled"
             );

            return true;
        }

        public async Task<bool> addSoap(soapDto dto)
        {  
            var appointment = _context.SoapNotes.Where(s=>s.AppointmentId == dto.AppointmentId).FirstOrDefault();
            if (appointment != null)
            {
                return false;
            }
            var data = new SoapNote
            {
                AppointmentId = dto.AppointmentId,
                Subjective = dto.Subjective,
                Objective = dto.Objective,
                Assessment = dto.Assessment,
                Plan = dto.Plan,
            };
            await _context.SoapNotes.AddAsync(data);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> updateStatus(int id)
        {
            var appointment = _context.Appointments.FirstOrDefault(a => a.Id == id);
            if (appointment == null)
            {
                return false;
            }
            appointment.Status = "Completed";
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<dynamic> previousAppointment(int id)
        {
            var patient = await _context.Appointments.Where(a => a.PatientId == id && (a.Status == "Cancelled" || a.Status == "Completed")).OrderBy(a => a.AppointmentDate).ThenBy(a=>a.AppointmentTime).ToListAsync();
            if(patient.Count != 0)
            {
                List<dynamic> result = new List<dynamic>();
                foreach(var item in patient)
                {
                    var providerdata = await _context.Users.Where(u=>u.Id == item.ProviderId).FirstOrDefaultAsync();
                    var name = providerdata.FirstName + "  " + providerdata.LastName;
                    var data = new {
                    name = name,
                    appointmentId = item.Id,
                    appointmentDate = item.AppointmentDate,
                    appointmentTime = item.AppointmentTime,
                    appointmentStatus = item.Status,
                    };
                    result.Add(data);
                }
                return result;
            }
            var provider = await _context.Appointments.Where(a => a.ProviderId == id && (a.Status == "Cancelled" || a.Status == "Completed")).OrderBy(a => a.AppointmentDate).ThenBy(a => a.AppointmentTime).ToListAsync();
            if(provider.Count != 0)
            {
                List<dynamic> result = new List<dynamic>();
                foreach (var item in provider)
                {
                    var patientdata = await _context.Users.Where(u => u.Id == item.PatientId).FirstOrDefaultAsync();
                    var name = patientdata.FirstName + "  " + patientdata.LastName;
                    var data = new
                    {
                        name = name,
                        appointmentId = item.Id,
                        appointmentDate = item.AppointmentDate,
                        appointmentTime = item.AppointmentTime,
                        appointmentStatus = item.Status,
                    };
                    result.Add(data);
                }
                return result;
            }
            return null;
        }


        public async Task<dynamic> viewAppointment(int id)
        {
            var appointmentDetail = await _context.Appointments.Where(a=>a.Id == id).FirstOrDefaultAsync();
            if(appointmentDetail != null)
            {
                var patientDetail = await _context.Users.Where(U=>U.Id == appointmentDetail.PatientId).FirstOrDefaultAsync();
                var patientsName = patientDetail.FirstName + "  " + patientDetail.LastName;
                var providerDetail = await _context.Users.Where(u=>u.Id == appointmentDetail.ProviderId).FirstOrDefaultAsync();
                var providersName = providerDetail.FirstName + "  " + providerDetail.LastName;
                var soapDetails = await _context.SoapNotes.Where(s => s.AppointmentId == id).FirstOrDefaultAsync();

                var data = new {
                    providerName = providersName,
                    patientName = patientsName,
                    appointmentDate = appointmentDetail.AppointmentDate,
                    appointmentTime = appointmentDetail.AppointmentTime,
                    cheifComplaint = appointmentDetail.CheifComplaint,
                    fee = appointmentDetail.Fee,
                    subjective = soapDetails.Subjective,
                    objective = soapDetails.Objective,
                    assessment = soapDetails.Assessment,
                    plan = soapDetails.Plan,
                };

                return data;

            }
            return null;
        }
    }
}
