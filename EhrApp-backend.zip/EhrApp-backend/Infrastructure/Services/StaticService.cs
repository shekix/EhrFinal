﻿using Core.Interfaces;
using Domain.Provider;
using Domain.StateCity;
using Domain.User;
using Infrastructure.Database;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.Services
{
    public class StaticService : IStaticService
    {
        private readonly AppDbContext _context;

        public StaticService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Country>> Countries()
        {
            var result = await _context.Countries.ToListAsync();
            if (result.Count > 0)
            {
                return result;
            }
            return null;
        }

        public async Task<IEnumerable<State>> States(int id)
        {
            var result = await _context.States.Where(s=>s.CountryId == id).ToListAsync();   
            if (result.Count > 0)
            {
                return result;
            }
            return null;
        }

        public async Task<IEnumerable<userType>> UserTypes()
        {
            var result = await _context.UserType.ToListAsync();
            if (result.Count > 0)
            {
                return result;
            }
            return null;
        }

        public async Task<IEnumerable<Gender>> Genders()
        {
            var result = await _context.Genders.ToListAsync();
            if (result.Count > 0)
            {
                return result;
            }
            return null;
        }

        public async Task<IEnumerable<BloodGroup>> BloodGroups()
        {
            var result = await _context.BloodGroups.ToListAsync();
            if (result.Count > 0)
            {
                return result;
            }
            return null;
        }

        public async Task<IEnumerable<Qualification>> Qualifications()
        {
            var result = await _context.Qualifications.ToListAsync();
            if (result.Count > 0)
            {
                return result;
            }
            return null;
        }

        public async Task<IEnumerable<Specialization>> Specializations()
        {
            var result = await _context.Specializations.ToListAsync();
            if (result.Count > 0)
            {
                return result;
            }
            return null;
        }
    }
}
