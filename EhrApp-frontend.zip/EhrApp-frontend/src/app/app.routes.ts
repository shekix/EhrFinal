import { Routes } from '@angular/router';
import { MainComponent } from '../components/main/main.component';
import { LoginComponent } from '../components/login/login.component';
import { PatientRegistrationComponent } from '../components/patient-registration/patient-registration.component';
import { ProviderRegistrationComponent } from '../components/provider-registration/provider-registration.component';
import { HomeComponent } from '../components/home/home.component';
import { ProfileComponent } from '../components/profile/profile.component';
import { ChangePassComponent } from '../components/change-pass/change-pass.component';
import { AppointmentsComponent } from '../components/appointments/appointments.component';
import { AddAppointmentComponent } from '../components/add-appointment/add-appointment.component';
import { PaymentComponent } from '../components/payment/payment.component';
import { AppointmentDetailsComponent } from '../components/appointment-details/appointment-details.component';
import { AppointmentHistoryComponent } from '../components/appointment-history/appointment-history.component';
import { masterGuard } from '../master.guard';
import { providerGuard } from '../provider.guard';
import { ChatComponent } from '../components/chat/chat.component';

export const routes: Routes = [
    {
        path:"",
        component:MainComponent
    },
    {
        path:"providerRegister",
        component:ProviderRegistrationComponent
    },
    {
        path:"patientRegister",
        component:PatientRegistrationComponent
    },
    {
        path:"login",
        component:LoginComponent
    },
    {
        path:"home",
        component:HomeComponent,
        canActivate:[masterGuard],
        children:[
            {
                path:"profile",
                component:ProfileComponent
            },
            {
                path:"changePass",
                component:ChangePassComponent
            },
            {
                path:"appointments",
                component:AppointmentsComponent
            },
            {
                path:"addAppointment",
                component:AddAppointmentComponent
            },
            {
                path:"payment",
                component:PaymentComponent
            },
            {
                path:"appointments/:id",
                component:AppointmentDetailsComponent,
                canActivate:[providerGuard]
            },
            {
                path:"history",
                component:AppointmentHistoryComponent
            },
            {
                path:"chat/:id",
                component:ChatComponent
            }
        ]
    }
];
