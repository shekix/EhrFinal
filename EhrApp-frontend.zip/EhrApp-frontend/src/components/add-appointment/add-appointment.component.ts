import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { AppointmentService } from '../../services/appointment.service';
import { CurrencyPipe, DatePipe, formatDate } from '@angular/common';
import {  ActivatedRoute, Router, RouterOutlet } from '@angular/router';
import * as bootstrap from 'bootstrap';
import { loadStripe } from '@stripe/stripe-js';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-add-appointment',
  standalone: true,
  imports: [ReactiveFormsModule,RouterOutlet,CurrencyPipe],
  templateUrl: './add-appointment.component.html',
  styleUrl: './add-appointment.component.css'
})
export class AddAppointmentComponent {

  Specializations:any[] = [];
  Providers:any[] = [];
  Patients:any[] = [];
  date = formatDate(new Date(),'yyyy-MM-dd','en');
  aptDetails:any;
  stripe:any;
  Elements: any;
  timeMin:any;
  card: any;
  role = sessionStorage.getItem('role');

  constructor(private appointmentApi:AppointmentService,private route:Router,private activeRoute:ActivatedRoute,private toast:ToastrService){}

  ngOnInit(){
    this.getProviders();
    this.getPatients();
  }

  addAppointmentForm = new FormGroup({
    patientId:new FormControl('',[Validators.required]),
    providerId:new FormControl('',[Validators.required]),
    appointmentDate:new FormControl('',[Validators.required]),
    appointmentTime:new FormControl('',[Validators.required]),
    cheifComplaint:new FormControl('',[Validators.required]),
    status:new FormControl('Scheduled'),
    fee:new FormControl({value:'select Provider',disabled:true})
    })

    getSpecializations(){
      this.appointmentApi.getSpecialization().subscribe((data:any)=>{
        this.Specializations = data;
        })
    }

    getProviders(){
      this.appointmentApi.getProviders().subscribe((data:any)=>{
        this.Providers = data;    
      })
    }

    getPatients(){
      this.appointmentApi.getPatients().subscribe((data:any)=>{
        this.Patients = data
      })
    }


    getProvidersById(event:any){
      this.Providers = [];
      this.appointmentApi.getProviderById(event.target.value).subscribe((data:any)=>{
        this.Providers = data;
      })
    }

    changefee(event:any){
      var provider =  this.Providers.filter(x=>x.id == event.target.value)
      this.addAppointmentForm.get('fee')?.setValue(provider[0].visitingCharge) 
    }

     book(){
      console.log(this.addAppointmentForm.value);
      
      if(this.role=='Patient'){

        this.addAppointmentForm.get('patientId')?.clearValidators();
        this.addAppointmentForm.get('patientId')?.updateValueAndValidity();

        if(this.addAppointmentForm.invalid==false){
          this.aptDetails = {
            patientId:Number(sessionStorage.getItem('id')),
            providerId:this.addAppointmentForm.get('providerId')?.value,
            appointmentDate:formatDate(this.addAppointmentForm.get('appointmentDate')?.value!,'yyyy-MM-dd','en'),
            appointmentTime:this.addAppointmentForm.get('appointmentTime')?.value,
            cheifComplaint:this.addAppointmentForm.get('cheifComplaint')?.value,
            status:this.addAppointmentForm.get('status')?.value,
            fee:this.addAppointmentForm.get('fee')?.value
          }
          
          const otpModal = new bootstrap.Modal(document.getElementById('paymentModal')!);
          otpModal.show();
            loadStripe('pk_test_51QUPDm2K94hGf7CbFdRXftVkSb5gMF9s5BfQVK4HWCiZ5WLI1PydgMsYnMvl47RITYprOBmYGQyl35mqseEZErk300IO2eOyqL').then((stripe:any) => {
            this.stripe = stripe;
            this.Elements = stripe.elements();
            this.card = this.Elements.create('card');
            this.card.mount('#card-element');
            });
        }
        else{
          this.addAppointmentForm.markAllAsTouched();
        }
      }

      else{
        this.addAppointmentForm.get('providerId')?.clearValidators();
        this.addAppointmentForm.get('providerId')?.updateValueAndValidity();
        if(this.addAppointmentForm.invalid == false){
          this.aptDetails = {
            patientId:this.addAppointmentForm.get('patientId')?.value,
            providerId:Number(sessionStorage.getItem('id')),
            appointmentDate:formatDate(this.addAppointmentForm.get('appointmentDate')?.value!,'yyyy-MM-dd','en'),
            appointmentTime:this.addAppointmentForm.get('appointmentTime')?.value,
            cheifComplaint:this.addAppointmentForm.get('cheifComplaint')?.value,
            status:this.addAppointmentForm.get('status')?.value,
            fee:0
          }

          this.appointmentApi.addAppointment(this.aptDetails).subscribe({
            next : (res:any)=>{
              console.log(res);
              
              this.toast.success('your appointment has been scheduled')
              this.route.navigateByUrl('home/appointments')
            }, 
            error:(error)=>{
              if(error.value == null){
                this.toast.error('Time must be 1hr from now')
              }else{
                this.toast.error('an error occured scheduling your appointment');
              }
              
            }
          });

        }
        else{
          this.addAppointmentForm.markAllAsTouched();
        }
      }
      

    //  this.appointmentApi.setAptDetails(this.aptDetails);
    //  this.appointmentApi.aptDetails$.subscribe((data:any)=>{
    //   console.log(data);
    //  })

    }



    // onDateChange(event: any) {
    //   const selectedDate = event.target.value;
    //   const today = new Date().toISOString().split('T')[0]; 
  
    //   if (selectedDate === today) {
    //     // If today is selected, set the time min to current time
    //     const currentTime = new Date();
    //     const hours = String(currentTime.getHours()).padStart(2, '0');
    //     const minutes = String(currentTime.getMinutes()).padStart(2, '0');
    //     this.timeMin = `${hours}:${minutes}`;
    //   } else {
    //     this.timeMin = '00:00'; // Reset timeMin to allow any time for future dates
    //   }
    // }
  
  
    // isTimeValid(): boolean {
    //   const selectedDate = new Date(this.addAppointmentForm.value.appointmentDate!);
    //   const today = new Date();
    //   if (selectedDate.toDateString() === today.toDateString()) {
    //     const selectedTime = this.addAppointmentForm.value.appointmentDate!;
    //     const currentTime = today.getHours() + today.getMinutes() / 60;
    //     const selectedTimeValue = parseInt(selectedTime.split(':')[0]) + parseInt(selectedTime.split(':')[1]) / 60;
    //     return selectedTimeValue > currentTime + 1;
    //   }
    //   return true;
    // }


    async handlePayment() {
    const amount = Number(this.aptDetails.fee);
    
    const paymentIntent = await this.appointmentApi.createPaymentIntent(amount).toPromise();

    const { clientSecret } = paymentIntent;

    
    const result = await this.stripe.confirmCardPayment(clientSecret, {
      payment_method: {
        card: this.card,
        billing_details: {
          name: 'Test User' 
        }
      }
    });

    if (result.error) {
      console.log('Payment failed', result.error);
    } else {
      if (result.paymentIntent.status === 'succeeded') {
        this.toast.success('payment successful!')
        this.appointmentApi.addAppointment(this.aptDetails).subscribe({
          next : (res:any)=>{
            this.toast.success('your appointment has been scheduled')
            this.route.navigateByUrl('home/appointments')
          }, 
          error:(error)=>{
            if(error.value == null){
              this.toast.error('Time must be 1hr from now')
            }else{
              this.toast.error('an error occured scheduling your appointment');
            }
          }
        });
      }
    }

  }



    get ProviderId() : FormControl{
      return this.addAppointmentForm.get('providerId') as FormControl;
    } 

    get PatientId() : FormControl{
      return this.addAppointmentForm.get('patientId') as FormControl;
    } 

    get aptDate() : FormControl{
      return this.addAppointmentForm.get('appointmentDate') as FormControl;
    }
    get aptTime() : FormControl{
      return this.addAppointmentForm.get('appointmentTime') as FormControl;
    }
    get complaint() : FormControl{
      return this.addAppointmentForm.get('cheifComplaint') as FormControl;
    }
}
