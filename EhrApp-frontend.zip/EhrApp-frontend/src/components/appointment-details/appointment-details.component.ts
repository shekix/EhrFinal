import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AppointmentService } from '../../services/appointment.service';
import { DatePipe } from '@angular/common';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-appointment-details',
  standalone: true,
  imports: [DatePipe,ReactiveFormsModule],
  templateUrl: './appointment-details.component.html',
  styleUrl: './appointment-details.component.css'
})
export class AppointmentDetailsComponent implements OnInit{

  appointmentId:any;
  appointmentData:any;
  pfp:any;
  age:any;
  constructor(private activatedRoute:ActivatedRoute,private appointmentSerivce:AppointmentService,private appoinmentApi:AppointmentService,private toast:ToastrService,private route:Router){}

  ngOnInit() {
        this.appointmentId = this.activatedRoute.snapshot.paramMap.get('id');
        this.appointmentSerivce.getAppointmentDetails(this.appointmentId).subscribe({
          next: (res:any)=>{
            this.appointmentData = res;
            this.pfp = "https://localhost:7055"+this.appointmentData[0].ProfileImage;
            this.age = this.calculateAge(this.appointmentData[0].Dob)
            console.log(this.age);
            
            console.log(this.appointmentData);
            console.log(this.pfp);
          },
          error: (error)=>{

          }
        })
        
        
  }
  
  
    addSoapForm = new FormGroup({
      appointmentId:new FormControl(''),
      subjective:new FormControl('',[Validators.required]),
      objective:new FormControl('',[Validators.required]),
      assessment:new FormControl('',[Validators.required]),
      plan:new FormControl('',[Validators.required]),
      })


  calculateAge(dob: Date): number {
    const today = new Date();
    const birthDate = new Date(dob);
    let age = today.getFullYear() - birthDate.getFullYear();
    const m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return age;
  }


  get Subjective() : FormControl{
    return this.addSoapForm.get('subjective') as FormControl;
  } 

  get Objective() : FormControl{
    return this.addSoapForm.get('objective') as FormControl;
  } 

  get Assessment() : FormControl{
    return this.addSoapForm.get('assessment') as FormControl;
  } 

  get Plan() : FormControl{
    return this.addSoapForm.get('plan') as FormControl;
  } 

  onComplete(){
    if(this.addSoapForm.invalid == false)
    {
      var data = {... this.addSoapForm.value}
      data.appointmentId = this.appointmentId;
      this.appoinmentApi.addSoap(data).subscribe({
        next :(res:any)=>{
          this.appoinmentApi.updateStatus(this.appointmentId).subscribe({
            next:(res:any)=>{
              this.toast.success('appointment completed')
              this.route.navigateByUrl('home/appointments')
            },
            error:(error)=>{
              this.toast.error('error updating status');
            }
          })
        },
        error : (error)=>{
          this.toast.error('error adding saop notes');
        }
      })
      
    }
    else
    {
      this.addSoapForm.markAllAsTouched();
    }
  }

}
