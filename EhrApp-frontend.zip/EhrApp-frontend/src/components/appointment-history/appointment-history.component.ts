import { Component, OnInit } from '@angular/core';
import { AppointmentService } from '../../services/appointment.service';
import * as bootstrap from 'bootstrap';

@Component({
  selector: 'app-appointment-history',
  standalone: true,
  imports: [],
  templateUrl: './appointment-history.component.html',
  styleUrl: './appointment-history.component.css'
})
export class AppointmentHistoryComponent implements OnInit{

patientAppointments:any[]=[];
providerAppointments:any[]=[];
id = sessionStorage.getItem("id");
role = sessionStorage.getItem("role");
appointmentDetail:any;

constructor(private appointmentApi:AppointmentService){}

ngOnInit(): void {
  this.appointmentApi.getPreviousAppointments(this.id).subscribe({
    next : (res:any)=>{
      if(this.role == 'Patient'){
        this.patientAppointments = res;
        console.log(this.patientAppointments);
        
      }
      else{
        this.providerAppointments = res;
        console.log(this.providerAppointments);
        
      }
    }
  })
}

view(id:any){
  this.appointmentApi.viewAppointment(id).subscribe((res:any)=>{
    this.appointmentDetail = res;
    console.log(this.appointmentDetail);
  })

  const viewModal = new bootstrap.Modal(document.getElementById('viewModal')!);
  viewModal.show();


}

changeBorder(status:any){
if(status === "Cancelled"){
  return '1px solid red'
}
  return '1px solid green';
}


}
