import { Component, OnInit } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { AppointmentService } from '../../services/appointment.service';
import { DatePipe, formatDate } from '@angular/common';
import { ToastrService } from 'ngx-toastr';
import Swal from 'sweetalert2';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import * as bootstrap from 'bootstrap';

@Component({
  selector: 'app-appointments',
  standalone: true,
  imports: [RouterLink,ReactiveFormsModule],
  templateUrl: './appointments.component.html',
  styleUrl: './appointments.component.css'
})
export class AppointmentsComponent implements OnInit {

patientAppointments:any[] = [];
providerAppointments:any[] = [];
role:any;
date = formatDate(new Date(),'yyyy-MM-dd','en');

ngOnInit(): void {
  this.role = sessionStorage.getItem('role');
  if(this.role =='Patient'){
    this.getPatientAppointments();
  }
  else{
    this.getProviderAppointments();
  }
  
}

constructor(private route:Router,private appointmentApi:AppointmentService,private toast:ToastrService){}

gotoAddAppointment(){
this.route.navigateByUrl('home/addAppointment')
}

getPatientAppointments(){
const id = sessionStorage.getItem('id');
this.appointmentApi.getPatientAppointmentDetails(id).subscribe((data:any)=>{  
  this.patientAppointments = data;

   console.log(this.patientAppointments);
   
})
}

getProviderAppointments(){
  const id = sessionStorage.getItem('id');
  this.appointmentApi.getProviderAppointmentDetails(id).subscribe((data:any)=>{  
  this.providerAppointments = data; 
  
})
}


onCancel(id:any){

    Swal.fire({
      title: "Are you sure?",
      text: "You want to cancel the appointment",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#8e44ad",
      cancelButtonColor: "#d33",
      cancelButtonText:"No",
      confirmButtonText: "Yes!"
    }).then((result) => {
      if (result.isConfirmed) {
        this.appointmentApi.cancelAppointment(id).subscribe({
          next : (res:any)=>{ 
            this.toast.success('Appointment cancelled!')
            
              this.getPatientAppointments();
            
            
              this.getProviderAppointments();
            
          },
          error : (error)=>{
            this.toast.error('an error occured');
          }
        })


    }
  })

}

    updateAppointmentForm = new FormGroup({
      appointmentId:new FormControl(''),
      appointmentDate:new FormControl('',[Validators.required]),
      appointmentTime:new FormControl('',[Validators.required]),
      cheifComplaint:new FormControl('',[Validators.required])
      })

onEdit(item:any){

    const otpModal = new bootstrap.Modal(document.getElementById('updateModal')!);
    otpModal.show();
    this.updateAppointmentForm.patchValue({
      appointmentId:item.id,
      appointmentDate:item.appointmentDate,
      appointmentTime:item.appointmentTime,
      cheifComplaint:item.cheifComplaint
    })
}

update(){
var data = {... this.updateAppointmentForm.value}

this.appointmentApi.updateAppointment(data).subscribe({
  next:(res:any) =>{
    this.toast.success('Changes saved');
    if(this.role =='Patient'){
      this.getPatientAppointments();
    }
    else{
      this.getProviderAppointments();
    }
  },
  error:(error)=>{
    this.toast.error('an error occured saving the changes');
  }
})

}

toAppointmentdetails(id:any){
  this.route.navigate(['home/appointments',id]);
}


goToChat(id:any){
  this.route.navigate(['home/chat',id])
}


get aptDate() : FormControl{
  return this.updateAppointmentForm.get('appointmentDate') as FormControl;
}
get aptTime() : FormControl{
  return this.updateAppointmentForm.get('appointmentTime') as FormControl;
}
get complaint() : FormControl{
  return this.updateAppointmentForm.get('cheifComplaint') as FormControl;
}


}
