import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-change-pass',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './change-pass.component.html',
  styleUrl: './change-pass.component.css'
})
export class ChangePassComponent {
  newPasswordDisplay:string = "none";
  confirmPassword:string = "none";  

  ChangePassForm = new FormGroup({
    newPassword:new FormControl('',[Validators.required,Validators.minLength(8)]),
    cpassword:new FormControl('')
  })

  constructor(private authApi:AuthService,private route:Router){}

  onSubmit(){
    if(this.Npassword.value == this.Cpassword.value)
      {
        this.confirmPassword = 'none';
        var data = {
          id:sessionStorage.getItem("id"),
          password:this.ChangePassForm.value.newPassword,
        }
  
        console.log(data);
        
        this.authApi.changePass(data).subscribe((res:any)=>{
          if(res=="unsuccessful"){
            Swal.fire({
              position: "top-end",
              icon: "error",
              title: "try again",
              showConfirmButton: false,
              timer: 2500
            });
          }
          else{
            Swal.fire({
              position: "top-end",
              icon: "success",
              title: "Password successfully changed",
              text:"Login again",
              showConfirmButton: false,
              timer: 2500
            });
            sessionStorage.removeItem("token");
            this.route.navigate(['/login'])
          }
        })
      }
      else
      {
        this.confirmPassword = 'inline';
      }
    }
  

  get Npassword() : FormControl{
    return this.ChangePassForm.get('newPassword') as FormControl;
  } 
  get Cpassword():FormControl{
    return this.ChangePassForm.get('cpassword') as FormControl;
  }
}
