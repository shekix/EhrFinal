import { Component } from '@angular/core';
import { initializeApp } from 'firebase/app';
import { getDatabase, ref, set, onValue, child, push } from 'firebase/database';
import { firebaseConfig } from '../../services/firebase-config'
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';
const app = initializeApp(firebaseConfig);
const db = getDatabase(app);

@Component({
  selector: 'app-chat',
  standalone: true,
  imports: [FormsModule,CommonModule],
  templateUrl: './chat.component.html',
  styleUrl: './chat.component.css'
})
export class ChatComponent {

constructor(private activatedRoute:ActivatedRoute){}

  receiverId : any;
  message: string = '';
  messages: any[] = [];
  // Send message to receiver
  sendMessage(receiverId: string, message: string): void {
    console.log(receiverId +"" +message);
    
  const messageRef = ref(db, 'messages/' + receiverId + sessionStorage.getItem('id'));
  const newMessageRef = push(messageRef);
  set(newMessageRef, {
  senderId: sessionStorage.getItem('id'), 
  message: message,
  timestamp: Date.now(),
  });

  const senderMessageRef = ref(db, 'messages/' + sessionStorage.getItem('id') + receiverId);
  const senderNewMessageRef = push(senderMessageRef);
  set(senderNewMessageRef, {
    receiverId: receiverId,
    message: message,
    timestamp: Date.now(),
  });
  
  }
  // Listen for new messages for the receiver
  listenForMessages(receiverId: string): void {
 
  const messageRef = ref(db, 'messages/'+ sessionStorage.getItem('id') + receiverId );
  onValue(messageRef, (snapshot) => {
  const data = snapshot.val();
  if (data) {
  this.messages = Object.values(data).sort((a: any, b: any) => a.timestamp - b.timestamp);
  console.log(this.messages);
  
  }
  });

  }
  ngOnInit() {
  // Initialize listening to messages for a specific receiver
  this.receiverId = this.activatedRoute.snapshot.paramMap.get('id');

  this.listenForMessages(this.receiverId);
  }
}
