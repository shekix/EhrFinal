import { Component } from '@angular/core';
import { UserService } from '../../services/user.service';
import { Router, RouterLink, RouterOutlet } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [RouterOutlet,RouterLink],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent {
  userId =sessionStorage.getItem("id")
  pfp:any;
  userinfo:any;
  constructor(private userService:UserService,private route:Router,private authService:AuthService){}
  
  ngOnInit(): void {
      this.userService.getUser(this.userId).subscribe((data:any)=>{
      this.userinfo = data;
      this.userService.updateProfilePic("https://localhost:7055"+this.userinfo.profileImage);
      this.userService.currentprofilePic.subscribe((pic:any)=>{
        this.pfp = pic;
      })
      })      
}
  
  
  
  
  logout(){
    this.authService.logout();
    this.route.navigate(['/login'])
  }
}
