import { Component } from '@angular/core';
import { loadStripe } from '@stripe/stripe-js';
import { AppointmentService } from '../../services/appointment.service';
import { CurrencyPipe } from '@angular/common';
import { ActivatedRoute, NavigationStart, Router } from '@angular/router';
@Component({
  selector: 'app-payment',
  standalone: true,
  imports: [CurrencyPipe],
  templateUrl: './payment.component.html',
  styleUrl: './payment.component.css'
})
export class PaymentComponent {
  stripe: any;
  Elements: any;
  card: any;
  aptData:any;
constructor(private appointmentApi:AppointmentService,private router:Router,private activeroute:ActivatedRoute){

 
}

  ngOnInit(): void {


    this.aptData =  this.router.getCurrentNavigation()!.extras.state?.['response'];
    console.log(this.aptData);
    
    loadStripe('pk_test_51QUPDm2K94hGf7CbFdRXftVkSb5gMF9s5BfQVK4HWCiZ5WLI1PydgMsYnMvl47RITYprOBmYGQyl35mqseEZErk300IO2eOyqL').then((stripe:any) => {
      this.stripe = stripe;
      this.Elements = stripe.elements();
      this.card = this.Elements.create('card');
      this.card.mount('#card-element');

    });
  }


  async handlePayment() {
    const amount = Number(sessionStorage.getItem('amount'));
    
    const paymentIntent = await this.appointmentApi.createPaymentIntent(amount).toPromise();

    const { clientSecret } = paymentIntent;

    // Confirm the payment
    const result = await this.stripe.confirmCardPayment(clientSecret, {
      payment_method: {
        card: this.card,
        billing_details: {
          name: 'Test User' // You can replace with dynamic user data
        }
      }
    });

    if (result.error) {
      console.log('Payment failed', result.error);
    } else {
      if (result.paymentIntent.status === 'succeeded') {
        alert('Payment successful!');
      }
    }

  }
}
