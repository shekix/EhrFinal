import { CanActivateFn } from '@angular/router';
import { AuthService } from './services/auth.service';
import { inject } from '@angular/core';

export const masterGuard: CanActivateFn = (route, state) => {
  var service = inject(AuthService);

  return service.isLoggedin();
};
