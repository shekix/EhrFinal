import { inject } from '@angular/core';
import { CanActivateFn } from '@angular/router';

export const patientGuard: CanActivateFn = (route, state) => {
  var service = inject(patientGuard);

  return service.isPatientLoggedin();
};
