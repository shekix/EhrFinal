import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AppointmentService {

   http = inject(HttpClient)
   private url = 'https://localhost:7055/api/Appointment';

     public addAppointment(data:any):Observable<any>{
       return this.http.post<any>(`${this.url}/addAppointment`,data );
     }

     public getSpecialization():Observable<any[]>{
      return this.http.get<any[]>(`${this.url}/Specializations`);
     }

     public getProviders():Observable<any[]>{
      return this.http.get<any[]>(`${this.url}/Providers`);
     }

     public getPatients():Observable<any[]>{
      return this.http.get<any[]>(`${this.url}/Patients`);
     }

     public getProviderById(id:any):Observable<any[]>{
      return this.http.get<any[]>(`${this.url}/ProvidersById?Id=${id}`);
     }

     public createPaymentIntent(amount: number): Observable<any> {
      return this.http.post(`${this.url}/create-payment-intent`, { amount });
    }

    public getPatientAppointmentDetails(id:any):Observable<any[]>{
      return this.http.get<any[]>(`${this.url}/patientAppointmentDetails?PatientId=${id}`);
     }

     public getProviderAppointmentDetails(id:any):Observable<any[]>{
      return this.http.get<any[]>(`${this.url}/providerAppointmentDetails?ProviderId=${id}`);
     }

     public cancelAppointment(id:any):Observable<any>{
      return this.http.delete<any>(`${this.url}/cancel?appointmentId=${id}`)
     }

     public getAppointmentDetails(id:any):Observable<any[]>{
      return this.http.get<any[]>(`${this.url}/byId?Id=${id}`);
     }

     public addSoap(data:any):Observable<any>{
      return this.http.post<any>(`${this.url}/addSoap`,data );
    }

    public updateStatus(id:any):Observable<any>{
      return this.http.put<any>(`${this.url}/updateStatus?id=${id}`,null);
    }
     
    public getPreviousAppointments(id:any):Observable<any[]>{
      return this.http.get<any[]>(`${this.url}/previousAppointments?id=${id}`);
    }

    public updateAppointment(data:any):Observable<any>{
      return this.http.put<any>(`${this.url}/updateAppointment`,data);
    }
    
    public viewAppointment(id:any):Observable<any[]>{
      return this.http.get<any[]>(`${this.url}/viewAppointment?id=${id}`);
    }
}
