import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  http = inject(HttpClient)
  private userUrl = 'https://localhost:7055/api/User'
  private staticUrl = 'https://localhost:7055/api/Static'


  public getCountries():Observable<any[]>{
    return this.http.get<any[]>(`${this.staticUrl}/countries`);
   }

   public getStates(id:any):Observable<any[]>{
    return this.http.get<any[]>(`${this.staticUrl}/States?id=${id}`);
   }

   public getGender():Observable<any[]>{
    return this.http.get<any[]>(`${this.staticUrl}/Gender`);
   }

   public getBloodGroup():Observable<any[]>{
    return this.http.get<any[]>(`${this.staticUrl}/BloodGroup`);
   }

   public getQualification():Observable<any[]>{
    return this.http.get<any[]>(`${this.staticUrl}/Qualification`);
   }

   public getSpecialization():Observable<any[]>{
    return this.http.get<any[]>(`${this.staticUrl}/Specialization`);
   }

  public registerUser(data:any):Observable<any>{
    return this.http.post<any>(`${this.userUrl}/Register`,data );
  }

  public loginUser(data:any):Observable<any>{
    return this.http.post<any>(`${this.userUrl}/Login`,data ,{responseType :'text' as 'json'});
  }

  public verifyOtp(data:any):Observable<any>{
    return this.http.post<any>(`${this.userUrl}/2FA`,data,{responseType :'text' as 'json'});
  }

  public forgotPass(data:any):Observable<any>{
    return this.http.post<any>(`${this.userUrl}/ForgotPass?email=${data}`,data,{responseType :'text' as 'json'});
  }

  public changePass(data:any):Observable<any>{
    return this.http.put<any>(`${this.userUrl}/ChangePass`,data,{responseType :'text' as 'json'});
  }


  isProviderLoggedin(){
    return sessionStorage.getItem('role')=='Provider' ? true : false;
  }

  isPatientLoggedin(){
    return sessionStorage.getItem('role')=='Patient' ? true : false;
  }

  isLoggedin(){
    return sessionStorage.getItem('token') ? true : false;
  }


  logout(){
    sessionStorage.clear();
  }
}
