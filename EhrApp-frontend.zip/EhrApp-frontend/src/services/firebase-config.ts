export const firebaseConfig = {
    apiKey: "AIzaSyBa_u7NTVo1NZUTfRgCTVnHykHiqpTUVHg",
    authDomain: "ehrchat-be942.firebaseapp.com",
    projectId: "ehrchat-be942",
    storageBucket: "ehrchat-be942.firebasestorage.app",
    messagingSenderId: "76415065572",
    appId: "1:76415065572:web:9a16e5f43a2d6ddf07fbf1",
    measurementId: "G-43RWZ603Z0"
   };