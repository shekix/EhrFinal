import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  http = inject(HttpClient)
  

  private userUrl = 'https://localhost:7055/api/User';

  profilePic : BehaviorSubject<string> = new BehaviorSubject('');

  currentprofilePic = this.profilePic.asObservable();

  updateProfilePic(url:string){
    this.profilePic.next(url);
  }

  public getUser(id:any):Observable<any[]>{
    return this.http.get<any[]>(`${this.userUrl}/userById?id=${id}`);
   }

   public updateUser(data:any):Observable<any[]>{
    return this.http.put<any[]>(`${this.userUrl}/update`,data,{responseType :'text' as 'json'});
   }
}
